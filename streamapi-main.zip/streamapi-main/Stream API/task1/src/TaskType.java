public enum TaskType {

    CODING,
    READING,
    WRITING
}
